﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessor.Business.Contract
{
    /// <summary>
    /// Interface contract to implement source
    /// </summary>
    interface ISource
    {
        /// <summary>
        /// Fetches data from source
        /// </summary>
        /// <param name="sourcePath">source path to fetch data</param>
        /// <returns></returns>
        string FetchFromSource(string sourcePath);
    }
}
