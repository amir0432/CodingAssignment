﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessor.Business.Contract
{
    /// <summary>
    /// Interface contract to implement process data
    /// </summary>
    interface IProcess
    {
        /// <summary>
        /// Process data and print required output
        /// </summary>
        /// <param name="data">Input string data that has to be processed</param>
        /// <returns></returns>
        string ProcessData(string data);
    }
}
