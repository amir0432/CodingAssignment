﻿using DataProcessor.Business.Contract;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessor.Business.Implementation
{
    /// <summary>
    /// Source class for file source
    /// </summary>
    class SourceFile : ISource
    {
        /// <summary>
        /// Fetches data from source
        /// </summary>
        /// <param name="sourcePath">source path to fetch data</param>
        /// <returns>string data read from file</returns>
        public string FetchFromSource(string sourcePath)
        {
            string line;
            FileStream fileStream = new FileStream(sourcePath, FileMode.Open);
            using (StreamReader reader = new StreamReader(fileStream))
            {
                line = reader.ReadLine();
            }
            return line;
        }
    }
}
