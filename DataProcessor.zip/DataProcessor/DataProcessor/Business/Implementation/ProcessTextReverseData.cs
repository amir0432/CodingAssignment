﻿using DataProcessor.Business.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessor.Business.Implementation
{
    /// <summary>
    /// Process class for textReverse data
    /// </summary>
    class ProcessTextReverseData : IProcess
    {
        /// <summary>
        /// Process data and print required output
        /// </summary>
        /// <param name="data">Input string data that has to be processed</param>
        /// <returns>First 6 letters of presumably textual data in reverse order in UTF8 format</returns>
        public string ProcessData(string data)
        {
            data = data.Substring(0, Math.Min(data.Length, 6));
            char[] charArray = data.ToCharArray();
            Array.Reverse(charArray);
            byte[] bytes = Encoding.Default.GetBytes(new string(charArray));
            string output = Encoding.UTF8.GetString(bytes);

            return output;
        }
    }
}
