﻿using DataProcessor.Business.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessor.Business.Implementation
{
    /// <summary>
    /// Process class for binary data
    /// </summary>
    class ProcessBinaryData : IProcess
    {
        /// <summary>
        /// Process data and print required output
        /// </summary>
        /// <param name="data">Input string data that has to be processed</param>
        /// <returns>First 5 bytes of data in base64 format</returns>
        public string ProcessData(string data)
        {
            int numOfBytes = data.Length / 8 < 5 ? data.Length / 8 : 5;
            byte[] bytes = new byte[numOfBytes];
            for (int i = 0; i < numOfBytes; ++i)
            {
                bytes[i] = Convert.ToByte(data.Substring(8 * i, 8), 2);
            }
            string output = Convert.ToBase64String(bytes);
            return output;
        }
    }
}
