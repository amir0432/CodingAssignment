﻿using DataProcessor.Business.Contract;
using System;
using System.Text;

namespace DataProcessor.Business.Implementation
{
    /// <summary>
    /// Process class for text data
    /// </summary>
    class ProcessTextData : IProcess
    {
        /// <summary>
        /// Process data and print required output
        /// </summary>
        /// <param name="data">Input string data that has to be processed</param>
        /// <returns>First 7 letters of presumably textual data in UTF8 format</returns>
        public string ProcessData(string data)
        {
            data = data.Substring(0, Math.Min(data.Length, 7));
            byte[] bytes = Encoding.Default.GetBytes(data);
            string output = Encoding.UTF8.GetString(bytes);
            return output;
        }
    }
}
