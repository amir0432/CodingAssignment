﻿using DataProcessor.Business.Contract;
using DataProcessor.Factory;
using System;

namespace DataProcessor
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create factory object to fetch implementation for file type of source, it can be changed to any source type in future
            FactorySource objFactorySource = new();
            ISource objSource = objFactorySource.GetDataFromSource("file");
            
            //Read file path
            Console.WriteLine("Please enter file path");
            string sourcePath = Console.ReadLine();

            //Read data type
            Console.WriteLine("Please enter data type");
            string dataType = Console.ReadLine();

            //Get implimentation of process data depending on data type chosen via factory pattern
            FactoryProcessData objFactoryProcessData = new();
            IProcess objProcess = objFactoryProcessData.GetProcessFromDataType(dataType);

            if(objProcess is null)
            {
                Console.WriteLine("Invalid data type entered");
            }
            else
            {
                Console.WriteLine(objProcess.ProcessData(objSource.FetchFromSource(sourcePath)));
            }
        }
    }
}
