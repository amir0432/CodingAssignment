﻿using DataProcessor.Business.Contract;
using DataProcessor.Business.Implementation;

namespace DataProcessor.Factory
{
    /// <summary>
    /// Factory class to process data
    /// </summary>
    class FactoryProcessData
    {
        /// <summary>
        /// Factory method to get implimentation class for IProcess interface
        /// </summary>
        /// <param name="dataType">dataType to be implimented</param>
        /// <returns></returns>
        public IProcess GetProcessFromDataType(string dataType)
        {
            if (dataType.Equals("binary"))
                return new ProcessBinaryData();
            else if (dataType.Equals("text"))
                return new ProcessTextData();
            else if (dataType.Equals("textReverse"))
                return new ProcessTextReverseData();
            else
                return null;
        }
    }
}
