﻿using DataProcessor.Business.Contract;
using DataProcessor.Business.Implementation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessor.Factory
{
    /// <summary>
    /// Factory class to get source
    /// </summary>
    class FactorySource
    {
        /// <summary>
        /// Factory method to get source
        /// </summary>
        /// <param name="sourcePath"> path for source</param>
        /// <returns></returns>
        public ISource GetDataFromSource(string sourcePath)
        {
            if (sourcePath.Equals("file"))
                return new SourceFile();            
            else
                return null;
        }
    }
}
